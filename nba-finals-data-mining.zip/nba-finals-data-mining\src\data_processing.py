"""
NBA Finals Data Processing and Analysis Module
Handles data cleaning, preprocessing, and statistical analysis
"""

import pandas as pd
import numpy as np
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

class NBADataProcessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = None
        
    def load_data(self, filepath):
        """
        Load data from CSV file
        """
        try:
            return pd.read_csv(filepath)
        except Exception as e:
            print(f"Error loading data: {e}")
            return None
    
    def clean_finals_data(self, df):
        """
        Clean and preprocess NBA Finals game data
        """
        # Remove duplicates
        df = df.drop_duplicates()
        
        # Handle missing values
        df = df.fillna(method='ffill')
        
        # Convert data types
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
        
        # Calculate derived metrics
        if 'home_score' in df.columns and 'away_score' in df.columns:
            df['point_differential'] = df['home_score'] - df['away_score']
            df['total_points'] = df['home_score'] + df['away_score']
            df['home_win'] = (df['home_score'] > df['away_score']).astype(int)
        
        return df
    
    def calculate_team_efficiency(self, df):
        """
        Calculate team efficiency metrics
        """
        efficiency_metrics = {}
        
        if all(col in df.columns for col in ['ppg', 'fg_pct', 'rpg', 'apg']):
            df['offensive_rating'] = (df['ppg'] * df['fg_pct']) + (df['apg'] * 2)
            df['defensive_efficiency'] = 100 - (df['ppg'] * (1 - df['fg_pct']))
            df['rebounding_rate'] = df['rpg'] / df['ppg']
            
            efficiency_metrics['offensive_rating'] = df['offensive_rating'].mean()
            efficiency_metrics['defensive_efficiency'] = df['defensive_efficiency'].mean()
            efficiency_metrics['rebounding_rate'] = df['rebounding_rate'].mean()
        
        return df, efficiency_metrics
    
    def analyze_home_court_advantage(self, games_df):
        """
        Analyze home court advantage in Finals games
        """
        if 'home_win' not in games_df.columns:
            return None
        
        home_wins = games_df['home_win'].sum()
        total_games = len(games_df)
        home_win_rate = home_wins / total_games
        
        # Statistical significance test
        expected_rate = 0.5  # No advantage
        z_score = (home_win_rate - expected_rate) / np.sqrt(expected_rate * (1 - expected_rate) / total_games)
        p_value = 2 * (1 - stats.norm.cdf(abs(z_score)))
        
        return {
            'home_win_rate': home_win_rate,
            'home_wins': home_wins,
            'total_games': total_games,
            'z_score': z_score,
            'p_value': p_value,
            'significant': p_value < 0.05
        }
    
    def identify_key_factors(self, df, target_col='home_win'):
        """
        Identify key factors that influence game outcomes using Random Forest
        """
        # Select numeric features
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if target_col in numeric_cols:
            numeric_cols.remove(target_col)
        
        if len(numeric_cols) == 0:
            return None
        
        X = df[numeric_cols]
        y = df[target_col]
        
        # Handle missing values
        X = X.fillna(X.mean())
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train Random Forest
        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        rf.fit(X_train, y_train)
        
        # Make predictions
        y_pred = rf.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        
        # Feature importance
        feature_importance = pd.DataFrame({
            'feature': numeric_cols,
            'importance': rf.feature_importances_
        }).sort_values('importance', ascending=False)
        
        self.model = rf
        
        return {
            'accuracy': accuracy,
            'feature_importance': feature_importance,
            'classification_report': classification_report(y_test, y_pred)
        }
    
    def calculate_player_impact(self, player_df):
        """
        Calculate advanced player impact metrics
        """
        if not all(col in player_df.columns for col in ['points', 'rebounds', 'assists']):
            return player_df
        
        # Player Efficiency Rating (simplified)
        player_df['per'] = (
            player_df['points'] + 
            player_df['rebounds'] + 
            player_df['assists'] +
            player_df.get('steals', 0) +
            player_df.get('blocks', 0) -
            player_df.get('turnovers', 0)
        ) / player_df.get('games_played', 1)
        
        # True Shooting Percentage (simplified)
        if 'fg_pct' in player_df.columns and 'ft_pct' in player_df.columns:
            player_df['ts_pct'] = (
                player_df['points'] / 
                (2 * (player_df['points'] / player_df['fg_pct']))
            )
        
        return player_df
    
    def generate_trends_analysis(self, df, year_col='season'):
        """
        Generate trend analysis over multiple seasons
        """
        trends = {}
        
        if year_col not in df.columns:
            return trends
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        for col in numeric_cols:
            yearly_avg = df.groupby(year_col)[col].mean()
            
            # Calculate trend (slope of linear regression)
            years = range(len(yearly_avg))
            slope, intercept, r_value, p_value, std_err = stats.linregress(years, yearly_avg.values)
            
            trends[col] = {
                'slope': slope,
                'r_squared': r_value ** 2,
                'p_value': p_value,
                'trend_direction': 'increasing' if slope > 0 else 'decreasing',
                'yearly_averages': yearly_avg.to_dict()
            }
        
        return trends
    
    def create_summary_report(self, analysis_results):
        """
        Create a comprehensive summary report
        """
        report = {
            'timestamp': pd.Timestamp.now().isoformat(),
            'data_summary': {},
            'key_findings': [],
            'recommendations': []
        }
        
        # Add analysis results to report
        for key, value in analysis_results.items():
            if isinstance(value, dict):
                report[key] = value
            else:
                report['data_summary'][key] = str(value)
        
        # Generate key findings
        if 'home_court_advantage' in analysis_results:
            hca = analysis_results['home_court_advantage']
            if hca['significant']:
                report['key_findings'].append(
                    f"Home court advantage is statistically significant with {hca['home_win_rate']:.1%} win rate"
                )
        
        if 'key_factors' in analysis_results:
            kf = analysis_results['key_factors']
            top_factor = kf['feature_importance'].iloc[0]
            report['key_findings'].append(
                f"Most important factor for winning: {top_factor['feature']} ({top_factor['importance']:.3f})"
            )
        
        return report

if __name__ == "__main__":
    processor = NBADataProcessor()
    
    # Example usage
    print("NBA Finals Data Processing Module initialized")
    print("Use this module to clean and analyze NBA Finals data")
    print("\nKey functions:")
    print("- clean_finals_data(): Clean raw game data")
    print("- analyze_home_court_advantage(): Statistical analysis of home court effect")
    print("- identify_key_factors(): ML-based factor importance analysis")
    print("- calculate_player_impact(): Advanced player metrics")
    print("- generate_trends_analysis(): Multi-season trend analysis")