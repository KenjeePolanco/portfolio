"""
NBA Finals Data Collection Module
Handles data gathering from various sources for analysis
"""

import pandas as pd
import requests
from bs4 import BeautifulSoup
import time
import json
from datetime import datetime

class NBADataCollector:
    def __init__(self):
        self.base_url = "https://stats.nba.com/stats/"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
    def get_finals_games(self, start_year=2000, end_year=2023):
        """
        Collect NBA Finals game data for specified year range
        """
        finals_data = []
        
        for year in range(start_year, end_year + 1):
            try:
                # Simulate API call to NBA Stats
                season_data = {
                    'season': f"{year}-{str(year+1)[2:]}",
                    'games': self._get_season_finals_games(year)
                }
                finals_data.append(season_data)
                time.sleep(1)  # Rate limiting
                
            except Exception as e:
                print(f"Error collecting data for {year}: {e}")
                
        return finals_data
    
    def _get_season_finals_games(self, year):
        """
        Get finals games for a specific season
        """
        # Sample data structure - in real implementation, this would call actual APIs
        sample_games = [
            {
                'game_id': f'{year}041701',
                'date': f'{year}-06-01',
                'home_team': 'LAL',
                'away_team': 'BOS',
                'home_score': 108,
                'away_score': 102,
                'game_number': 1
            },
            {
                'game_id': f'{year}041702',
                'date': f'{year}-06-04',
                'home_team': 'LAL',
                'away_team': 'BOS',
                'home_score': 95,
                'away_score': 98,
                'game_number': 2
            }
        ]
        return sample_games
    
    def get_team_stats(self, teams, seasons):
        """
        Collect team statistics for analysis
        """
        team_stats = []
        
        for team in teams:
            for season in seasons:
                stats = {
                    'team': team,
                    'season': season,
                    'ppg': 110.5,  # Sample data
                    'fg_pct': 0.465,
                    'threep_pct': 0.358,
                    'ft_pct': 0.789,
                    'rpg': 45.2,
                    'apg': 24.8,
                    'spg': 7.6,
                    'bpg': 5.1
                }
                team_stats.append(stats)
                
        return pd.DataFrame(team_stats)
    
    def get_player_stats(self, player_ids, seasons):
        """
        Collect individual player statistics
        """
        player_stats = []
        
        for player_id in player_ids:
            for season in seasons:
                stats = {
                    'player_id': player_id,
                    'season': season,
                    'games_played': 82,
                    'minutes': 36.5,
                    'points': 25.2,
                    'rebounds': 8.1,
                    'assists': 6.3,
                    'steals': 1.2,
                    'blocks': 0.8,
                    'turnovers': 3.1,
                    'fg_pct': 0.485,
                    'threep_pct': 0.365,
                    'ft_pct': 0.821
                }
                player_stats.append(stats)
                
        return pd.DataFrame(player_stats)
    
    def scrape_basketball_reference(self, url):
        """
        Scrape additional data from Basketball Reference
        """
        try:
            response = requests.get(url, headers=self.headers)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Parse tables (implementation would depend on specific page structure)
            tables = soup.find_all('table')
            
            return self._parse_basketball_ref_table(tables[0]) if tables else None
            
        except Exception as e:
            print(f"Error scraping Basketball Reference: {e}")
            return None
    
    def _parse_basketball_ref_table(self, table):
        """
        Parse Basketball Reference table into DataFrame
        """
        rows = []
        headers = [th.text.strip() for th in table.find('thead').find_all('th')[1:]]
        
        for row in table.find('tbody').find_all('tr'):
            if row.get('class') and 'thead' in row.get('class'):
                continue
                
            cells = row.find_all(['td', 'th'])
            if len(cells) > 1:
                row_data = [cell.text.strip() for cell in cells[1:]]
                rows.append(row_data)
        
        return pd.DataFrame(rows, columns=headers)
    
    def save_data(self, data, filename):
        """
        Save collected data to file
        """
        if isinstance(data, pd.DataFrame):
            data.to_csv(f'data/raw/{filename}.csv', index=False)
        else:
            with open(f'data/raw/{filename}.json', 'w') as f:
                json.dump(data, f, indent=2)
        
        print(f"Data saved to data/raw/{filename}")

if __name__ == "__main__":
    collector = NBADataCollector()
    
    # Example usage
    finals_data = collector.get_finals_games(2015, 2023)
    collector.save_data(finals_data, 'finals_games_2015_2023')
    
    # Collect team stats
    teams = ['LAL', 'BOS', 'GSW', 'MIA', 'SAS']
    seasons = ['2020-21', '2021-22', '2022-23']
    team_stats = collector.get_team_stats(teams, seasons)
    collector.save_data(team_stats, 'team_stats')
    
    print("Data collection completed!")