# NBA Finals Analysis - Sample Data

This directory contains sample CSV files with NBA Finals data for analysis.

## Data Files

### finals_games.csv
Contains game-by-game results from NBA Finals series including:
- Game ID, Date, Teams, Scores
- Home/Away designations
- Game numbers within series

### team_stats.csv  
Team statistics for Finals participants including:
- Points per game, Field goal percentage
- Rebounds, Assists, Steals, Blocks
- Advanced efficiency metrics

### player_stats.csv
Individual player performance data including:
- Basic stats (points, rebounds, assists)
- Shooting percentages
- Advanced metrics and per-game averages

## Usage

These CSV files are used by the Python scripts in the src/ directory for analysis and visualization. Load them using pandas:

```python
import pandas as pd

games_df = pd.read_csv('data/finals_games.csv')
teams_df = pd.read_csv('data/team_stats.csv')
players_df = pd.read_csv('data/player_stats.csv')
```