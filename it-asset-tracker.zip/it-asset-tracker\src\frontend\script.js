// IT Asset Tracker JavaScript

class AssetTracker {
    constructor() {
        this.assets = [
            {
                id: 'IT001',
                name: 'Dell OptiPlex 7090',
                type: 'Desktop',
                status: 'In Use',
                assignedTo: 'John Smith'
            },
            {
                id: 'IT002',
                name: 'HP Laptop ProBook',
                type: 'Laptop',
                status: 'Available',
                assignedTo: ''
            },
            {
                id: 'IT003',
                name: 'Cisco Switch 2960',
                type: 'Network Equipment',
                status: 'In Use',
                assignedTo: 'Network Team'
            },
            {
                id: 'IT004',
                name: 'Adobe Creative Suite',
                type: 'Software',
                status: 'In Use',
                assignedTo: 'Design Team'
            },
            {
                id: 'IT005',
                name: 'Lenovo ThinkPad',
                type: 'Laptop',
                status: 'Maintenance',
                assignedTo: ''
            }
        ];
        this.init();
    }

    init() {
        this.updateDashboardStats();
        this.renderAssetTable();
        this.bindEvents();
    }

    updateDashboardStats() {
        const totalAssets = this.assets.length;
        const availableAssets = this.assets.filter(asset => asset.status === 'Available').length;
        const inUseAssets = this.assets.filter(asset => asset.status === 'In Use').length;
        const maintenanceAssets = this.assets.filter(asset => asset.status === 'Maintenance').length;

        document.getElementById('total-assets').textContent = totalAssets;
        document.getElementById('available-assets').textContent = availableAssets;
        document.getElementById('in-use-assets').textContent = inUseAssets;
        document.getElementById('maintenance-assets').textContent = maintenanceAssets;
    }

    renderAssetTable() {
        const tableBody = document.getElementById('asset-table-body');
        tableBody.innerHTML = '';

        this.assets.forEach(asset => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${asset.id}</td>
                <td>${asset.name}</td>
                <td>${asset.type}</td>
                <td><span class="status-badge status-${asset.status.toLowerCase().replace(' ', '-')}">${asset.status}</span></td>
                <td>${asset.assignedTo || 'Unassigned'}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="assetTracker.editAsset('${asset.id}')">Edit</button>
                    <button class="btn btn-sm btn-outline-danger ms-1" onclick="assetTracker.deleteAsset('${asset.id}')">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    bindEvents() {
        document.getElementById('add-asset-btn').addEventListener('click', () => {
            this.addAsset();
        });
    }

    addAsset() {
        const name = prompt('Enter asset name:');
        const type = prompt('Enter asset type:');
        
        if (name && type) {
            const newAsset = {
                id: 'IT' + String(this.assets.length + 1).padStart(3, '0'),
                name: name,
                type: type,
                status: 'Available',
                assignedTo: ''
            };
            
            this.assets.push(newAsset);
            this.updateDashboardStats();
            this.renderAssetTable();
        }
    }

    editAsset(assetId) {
        const asset = this.assets.find(a => a.id === assetId);
        if (asset) {
            const newName = prompt('Enter new name:', asset.name);
            const newAssignedTo = prompt('Assigned to:', asset.assignedTo);
            
            if (newName !== null) {
                asset.name = newName;
                asset.assignedTo = newAssignedTo || '';
                this.renderAssetTable();
            }
        }
    }

    deleteAsset(assetId) {
        if (confirm('Are you sure you want to delete this asset?')) {
            this.assets = this.assets.filter(asset => asset.id !== assetId);
            this.updateDashboardStats();
            this.renderAssetTable();
        }
    }

    searchAssets(query) {
        const filteredAssets = this.assets.filter(asset => 
            asset.name.toLowerCase().includes(query.toLowerCase()) ||
            asset.type.toLowerCase().includes(query.toLowerCase()) ||
            asset.id.toLowerCase().includes(query.toLowerCase())
        );
        return filteredAssets;
    }
}

// Initialize the Asset Tracker when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.assetTracker = new AssetTracker();
});

// Export functions for demo purposes
window.AssetTracker = AssetTracker;