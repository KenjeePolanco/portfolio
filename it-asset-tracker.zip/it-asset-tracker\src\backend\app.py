# IT Asset Tracker Backend (Flask)
from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///assets.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Asset Model
class Asset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    asset_type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='Available')
    assigned_to = db.Column(db.String(100))
    purchase_date = db.Column(db.Date)
    warranty_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'asset_id': self.asset_id,
            'name': self.name,
            'asset_type': self.asset_type,
            'status': self.status,
            'assigned_to': self.assigned_to,
            'purchase_date': self.purchase_date.isoformat() if self.purchase_date else None,
            'warranty_date': self.warranty_date.isoformat() if self.warranty_date else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/assets', methods=['GET'])
def get_assets():
    assets = Asset.query.all()
    return jsonify([asset.to_dict() for asset in assets])

@app.route('/api/assets', methods=['POST'])
def create_asset():
    data = request.get_json()
    
    asset = Asset(
        asset_id=data['asset_id'],
        name=data['name'],
        asset_type=data['asset_type'],
        status=data.get('status', 'Available'),
        assigned_to=data.get('assigned_to')
    )
    
    db.session.add(asset)
    db.session.commit()
    
    return jsonify(asset.to_dict()), 201

@app.route('/api/assets/<int:asset_id>', methods=['PUT'])
def update_asset(asset_id):
    asset = Asset.query.get_or_404(asset_id)
    data = request.get_json()
    
    asset.name = data.get('name', asset.name)
    asset.asset_type = data.get('asset_type', asset.asset_type)
    asset.status = data.get('status', asset.status)
    asset.assigned_to = data.get('assigned_to', asset.assigned_to)
    
    db.session.commit()
    
    return jsonify(asset.to_dict())

@app.route('/api/assets/<int:asset_id>', methods=['DELETE'])
def delete_asset(asset_id):
    asset = Asset.query.get_or_404(asset_id)
    db.session.delete(asset)
    db.session.commit()
    
    return '', 204

@app.route('/api/assets/stats', methods=['GET'])
def get_asset_stats():
    total = Asset.query.count()
    available = Asset.query.filter_by(status='Available').count()
    in_use = Asset.query.filter_by(status='In Use').count()
    maintenance = Asset.query.filter_by(status='Maintenance').count()
    
    return jsonify({
        'total': total,
        'available': available,
        'in_use': in_use,
        'maintenance': maintenance
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)