# IT Asset Tracker

A comprehensive IT asset management system designed to track hardware and software assets within an organization.

## Features

- Asset inventory management
- Hardware and software tracking
- Asset lifecycle monitoring
- User assignment tracking
- Maintenance scheduling
- Reporting and analytics

## Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript
- **Backend**: Python/Flask or Node.js
- **Database**: SQLite/MySQL
- **Additional**: Bootstrap for responsive design

## Project Structure

```
it-asset-tracker/
├── src/
│   ├── frontend/
│   │   ├── index.html
│   │   ├── styles.css
│   │   └── script.js
│   ├── backend/
│   │   ├── app.py
│   │   └── models.py
│   └── database/
│       └── schema.sql
├── docs/
│   └── user-guide.md
└── README.md
```

## Installation

1. Clone or download this project
2. Install required dependencies
3. Set up the database
4. Run the application

## Usage

The IT Asset Tracker provides an intuitive web interface for managing organizational assets. Users can add, edit, and track various types of IT equipment and software licenses.

## Author

Kenjee Polanco

## License

This project is for portfolio demonstration purposes.